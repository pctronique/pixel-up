# simple-web-worker

> NOTE: This example repository has been archived. The example code and live example can now be found at [dom-examples/web-workers/simple-web-worker](https://github.com/mdn/dom-examples/tree/master/web-workers/simple-web-worker)
